package patterns;

//observer
public interface Observer {
    void actualizar(String mensaje);
}
