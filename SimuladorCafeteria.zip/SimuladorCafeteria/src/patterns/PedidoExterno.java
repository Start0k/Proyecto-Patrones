package patterns;

public class PedidoExterno {
    public String getTextoPedido() {
        return "Latte desde app externa";
    }
}
